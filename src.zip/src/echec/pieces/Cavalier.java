package echec.pieces;

import java.util.ArrayList;

import echec.Coordonn�e;
import echec.Echiquier;

public class Cavalier extends Pi�ce {
	
	/**
	 * Constructeur d'un Cavalier
	 * @param couleur
	 * @param ligne
	 * @param colonne
	 */
    public Cavalier(String couleur, int ligne, int colonne) {
        super(couleur, ligne, colonne);
        this.type = "CAVALIER";
    }
    
    /**
	 * V�rifie qu'un coup est possible pour le cavalier
	 * @param e l'�chiquier actuel
	 * @param x ligne
	 * @param y colonne
	 * @return true si le coup est possible
	 */
    @Override
    public boolean estPossible(Echiquier e, int x, int y) {
    	if(e.getPi�ce(x, y) != null 
    			&& e.getPi�ce(x, y).getCouleur() == this.getCouleur())
    		return false;
    	
    	// 2 bas + 1 gauche
    	if(ligne + 2 == x && colonne - 1 == y)
    		return true;

    	// 2 bas + 1 droite
    	if(ligne + 2 == x && colonne + 1 == y)
    		return true;
    	
    	// 2 haut + 1 droite
    	if(ligne - 2 == x && colonne + 1 == y)
    		return true;
    	
    	// 2 haut + 1 gauche
    	if(ligne - 2 == x && colonne - 1 == y)
    		return true;
    	
    	// 2 droite + 1 bas
    	if(ligne + 1 == x && colonne + 2 == y)
    		return true;
    	
    	// 2 droite + 1 haut
    	if(ligne - 1 == x && colonne + 2 == y)
    		return true;
    	
    	// 2 gauche + 1 bas
    	if(ligne + 1 == x && colonne - 2 == y)
    		return true;
    	
    	// 2 gauche + 1 haut
    	if(ligne - 1 == x && colonne - 2 == y)
    		return true;
    	
        return false;
    }
    
    /**
	 * Retourne tous les coups possibles d'un cavalier sur l'�chiquier
	 * @param e l'�chiquier actuel
	 * @return coups la liste des coups possibles
	 */
    @Override
    public ArrayList<Coordonn�e> coupsPossibles(Echiquier e){
    	ArrayList<Coordonn�e> coups = new ArrayList<Coordonn�e>();
    	
    	// 2 bas + 1 gauche
    	if(ligne + 2 < Echiquier.MAX && colonne - 1 >= Echiquier.MIN - 1
    			&& (e.getPi�ce(ligne + 2, colonne - 1) == null
    			|| (e.getPi�ce(ligne + 2, colonne - 1) != null
    			&& e.getPi�ce(ligne + 2, colonne - 1).getCouleur() != this.getCouleur())))
    		coups.add(new Coordonn�e(ligne + 2, colonne - 1));

    	// 2 bas + 1 droite
    	if(ligne + 2 < Echiquier.MAX && colonne + 1 < Echiquier.MAX
    			&& (e.getPi�ce(ligne + 2, colonne + 1) == null
    			|| (e.getPi�ce(ligne + 2, colonne + 1) != null
    			&& e.getPi�ce(ligne + 2, colonne + 1).getCouleur() != this.getCouleur())))
    		coups.add(new Coordonn�e(ligne + 2, colonne + 1));
    	
    	// 2 haut + 1 droite
    	if(ligne - 2 >= Echiquier.MIN - 1 && colonne + 1 < Echiquier.MAX
    			&& (e.getPi�ce(ligne - 2, colonne + 1) == null
    			|| (e.getPi�ce(ligne - 2, colonne + 1) != null
    			&& e.getPi�ce(ligne - 2, colonne + 1).getCouleur() != this.getCouleur())))
    		coups.add(new Coordonn�e(ligne - 2, colonne + 1));
    	
    	// 2 haut + 1 gauche
    	if(ligne - 2 >= Echiquier.MIN - 1 && colonne - 1 >= Echiquier.MIN - 1
    			&& (e.getPi�ce(ligne - 2, colonne - 1) == null
    			|| (e.getPi�ce(ligne - 2, colonne - 1) != null
    			&& e.getPi�ce(ligne - 2, colonne - 1).getCouleur() != this.getCouleur())))
    		coups.add(new Coordonn�e(ligne - 2, colonne - 1));
    	
    	// 2 droite + 1 bas
    	if(ligne + 1 < Echiquier.MAX && colonne + 2 < Echiquier.MAX
    			&& (e.getPi�ce(ligne + 1, colonne + 2) == null
    			|| (e.getPi�ce(ligne + 1, colonne + 2) != null
    			&& e.getPi�ce(ligne + 1, colonne + 2).getCouleur() != this.getCouleur())))
    		coups.add(new Coordonn�e(ligne + 1, colonne + 2));
    	
    	
    	// 2 droite + 1 haut
    	if(ligne - 1 >= Echiquier.MIN - 1 && colonne + 2 < Echiquier.MAX
    			&& (e.getPi�ce(ligne - 1, colonne + 2) == null
    			|| (e.getPi�ce(ligne - 1, colonne + 2) != null
    			&& e.getPi�ce(ligne - 1, colonne + 2).getCouleur() != this.getCouleur())))
    		coups.add(new Coordonn�e(ligne - 1, colonne + 2));
    	
    	// 2 gauche + 1 bas
    	if(ligne + 1 < Echiquier.MAX && colonne - 2 >= Echiquier.MIN - 1
    			&& (e.getPi�ce(ligne + 1, colonne - 2) == null
    			|| (e.getPi�ce(ligne + 1, colonne - 2) != null
    			&& e.getPi�ce(ligne + 1, colonne - 2).getCouleur() != this.getCouleur())))
    		coups.add(new Coordonn�e(ligne + 1, colonne - 2));
    	
    	// 2 gauche + 1 haut
    	if(ligne - 1 >= Echiquier.MIN - 1 && colonne - 2 >= Echiquier.MIN - 1
    			&& (e.getPi�ce(ligne - 1, colonne - 2) == null
    			|| (e.getPi�ce(ligne - 1, colonne - 2) != null
    			&& e.getPi�ce(ligne - 1, colonne - 2).getCouleur() != this.getCouleur())))
    		coups.add(new Coordonn�e(ligne - 1, colonne - 2));
    	
    	return coups;
    }

    /**
	 * Retourne le caract�re repr�sentant la pi�ce
	 * @return le caract�re
	 */
    @Override
    public char getSymbole() { 
        return (couleur.equals("BLANC") ? 'C':'c');
    }
}
