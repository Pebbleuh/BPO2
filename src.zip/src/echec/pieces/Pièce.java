package echec.pieces;

import java.util.ArrayList;


import echec.Coordonn�e;
import echec.Echiquier;


public class Pi�ce {
    protected String couleur;
    protected String type;
    protected int ligne;
    protected int colonne;

    /**
     * Constructeur d'une Pi�ce
     * @param couleur
     * @param ligne
     * @param colonne
     */
    public Pi�ce(String couleur, int ligne, int colonne) {
        this.couleur = couleur;
        setCoordonn�e(ligne, colonne);
    }

    /**
     * Retourne tous les coups possibles d'une pi�ce sur l'�chiquier
     * @param e l'�chiquier actuel
     * @return null
     */
    public ArrayList<Coordonn�e> coupsPossibles(Echiquier e){
    	return null;
    }
    
    /**
     * Retourne la couleur d'une pi�ce
     * @return couleur
     */
    public String getCouleur() {
        return couleur;
    }
    
    /**
     * Retourne la ligne d'une pi�ce
     * @return ligne
     */
    public int getLigne() {
        return ligne;
    }

    /**
     * Retourne la colonne d'une pi�ce
     * @return colonne
     */
    public int getColonne() {
        return colonne;
    }
    
    /**
     * Retourne le type de la pi�ce
     * @return type
     */
	public String getType() {
		return type;
	}

	/**
     * Modifie les coordonn�es ligne et colonne
     * @param ligne
     * @param colonne
     */
    public void setCoordonn�e(int ligne, int colonne) {
    	this.ligne = ligne;
    	this.colonne = colonne;
    }

    /**
     * D�place la pi�ce aux coordonn�es d'arriv�e
     * @param e l'�chiquier actuel
     * @param d�part
     * @param arriv�e
     */
    public void d�placer(Echiquier e, Coordonn�e d�part, Coordonn�e arriv�e) {
    	int x = d�part.getLigne(), ligne = arriv�e.getLigne();
    	int y = d�part.getColonne(), colonne = arriv�e.getColonne();
    	
        if(this.type == "PION") {
        	Pion p = (Pion) this;
        	p.setPremierCoup(false);
        }
        
    	e.setPi�ce(x, y, null);
        setCoordonn�e(ligne, colonne);
        e.setPi�ce(ligne, colonne, this);  
    }

    /**
     * V�rifie qu'un coup est possible pour la pi�ce
     * @param e l'�chiquier actuel
     * @param x la ligne
     * @param y la colonne
     * @return false
     */
    public boolean estPossible(Echiquier e, int x, int y) {
        return false;
    }

    /**
     * Retourne le caract�re repr�sentant la pi�ce
     * @return ' '
     */
    public char getSymbole() { return ' '; }

    /**
     * Retourne la couleur et les coordonn�es de la pi�ce
     * @return s
     */
	public String toString() {
		String s = couleur;
		Coordonn�e c = new Coordonn�e(ligne, colonne);
		s += c.toString();
		return s;
	}
	
	/**
     * Place toutes les pi�ces sur l'�chiquier
     * @param e echiquier
     */
	public static void setEchiquier(Echiquier e) {
    	// pion
        for(int i = 0; i < Echiquier.MAX; ++i) {
        	e.setPi�ce(6, i, new Pion("BLANC", 6, i));
        	e.setPi�ce(1, i, new Pion("NOIR", 1, i));
        }
        
        // blanc
        e.setPi�ce(7, 0, new Tour("BLANC", 7, 0));
        e.setPi�ce(7, 7, new Tour("BLANC", 7, 7));
        e.setPi�ce(7, 1, new Cavalier("BLANC", 7, 1));
        e.setPi�ce(7, 6, new Cavalier("BLANC", 7, 6));
        e.setPi�ce(7, 2, new Fou("BLANC", 7, 2));
        e.setPi�ce(7, 5, new Fou("BLANC", 7, 5));
        e.setPi�ce(7, 3, new Reine("BLANC", 7, 3));
        e.setPi�ce(7, 4, e.getRoiBlanc());
        
        // noir
        e.setPi�ce(0, 0, new Tour("NOIR", 0, 0));
        e.setPi�ce(0, 7, new Tour("NOIR", 0, 7));
        e.setPi�ce(0, 1, new Cavalier("NOIR", 0, 1));
        e.setPi�ce(0, 6, new Cavalier("NOIR", 0, 6));
        e.setPi�ce(0, 2, new Fou("NOIR", 0, 2));
        e.setPi�ce(0, 5, new Fou("NOIR", 0, 5));
        e.setPi�ce(0, 3, new Reine("NOIR", 0, 3));
        e.setPi�ce(0, 4, e.getRoiNoir());
	}
}