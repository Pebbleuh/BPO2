package echec.pieces;

import java.util.ArrayList;

import echec.Coordonn�e;
import echec.Echiquier;

public class Roi extends Pi�ce {
	
    private static Pi�ce priseV�rif = null;
    private static Pi�ce priseCoupPossible = null;

    /**
     * Constructeur d'un Roi
     * @param couleur
     * @param ligne
     * @param colonne
     */
    public Roi(String couleur, int x, int y) {
        super(couleur, x, y);
        this.type = "ROI";
    }

    /**
     * V�rifie qu'un coup est possible pour le roi
     * @param e l'�chiquier actuel
     * @param x ligne
     * @param y colonne
     * @return true si le coup est possible
     */
    @Override
    public boolean estPossible(Echiquier e, int x, int y) {
    	if(e.getPi�ce(x, y) != null
    			&& e.getPi�ce(x, y).getCouleur() == this.getCouleur()) 
    		return false;
        
        // vertical ou horizontal
        if((ligne == (x + 1) && colonne == y)
        		|| (ligne == (x - 1) && colonne == y)
        		|| (ligne == x && colonne == (y + 1))
        		|| (ligne == x && colonne == (y - 1))) {
            return true;
        }

        // diagonale
        if((ligne == (x + 1) && colonne == (y + 1))
        		|| (ligne == (x + 1) && colonne == (y - 1))
        		|| (ligne == (x - 1) && colonne == (y + 1))
        		|| (ligne == (x - 1) && colonne == (y - 1))) {
        	return true;
        }
        
        return false;
    }
    
    /**
     * Retourne le caract�re repr�sentant la pi�ce
     * @return le caract�re
     */
    @Override
    public char getSymbole() {
    	return (couleur.equals("BLANC") ? 'R':'r');
    }
    
    /**
     * Retourne tous les coups possibles d'un roi sur l'�chiquier
     * @param e l'�chiquier en cours
     * @return coups
     */
    @Override
    public ArrayList<Coordonn�e> coupsPossibles(Echiquier e) {
        ArrayList<Coordonn�e> coups = new ArrayList<Coordonn�e>();
        
        for (int i = ligne - 1; i <= ligne + 1 && i < Echiquier.MAX; ++i) {
            if(i < 0)
                ++i;
            for (int j = colonne - 1; j <= colonne + 1 && j < Echiquier.MAX; ++j) {
                if(j < 0)
                    ++j;
                
                if(estPossible(e, i, j)) {
                	Coordonn�e d�part = new Coordonn�e(ligne, colonne);
                	Coordonn�e arriv�e = new Coordonn�e(i, j);
                	if(e.getPriseDernierCoup() != null)
                		priseCoupPossible = e.getPriseDernierCoup();
                	e.d�placer(d�part, arriv�e);
                	if(!�chec(e))
                		coups.add(new Coordonn�e(i, j));
                	e.annulerDernierCoup(d�part, arriv�e);
                	e.setPriseDernierCoup(priseCoupPossible);
                	priseCoupPossible = null;
                }
            }
        }
        return coups;
    }

    /**
     * V�rifie si le roi est en �chec ou non (la pi�ce adverse peut se d�placer � sa position)
     * @param e l'�chiquier en cours
     * @return false si le roi n'est pas en �chec
     */
    public boolean �chec(Echiquier e) {
    	for (int i = 0; i < Echiquier.MAX; ++i) {
    		for (int j = 0; j < Echiquier.MAX; ++j) {
    			Pi�ce p = e.getPi�ce(i, j);
    			if(p != null && !(ligne == i && colonne == j))
    				if(p.couleur != this.couleur && p.estPossible(e, ligne, colonne)) {
    					return true;
    				}
    		}
    	}
    	return false;
    }
    
    /**
     * V�rifie si le roi peut �tre prot�g�
     * @param e l'�chiquier actuel
     * @return false s'il ne peut pas �tre prot�g�
     */
    public boolean peutEtreProt�g�(Echiquier e) {
    	ArrayList<Pi�ce> pi�ces = new ArrayList<Pi�ce>();
    	
    	for (int i = 0; i < Echiquier.MAX; ++i) {
    		for (int j = 0; j < Echiquier.MAX; ++j) {
    			Pi�ce p = e.getPi�ce(i, j);
    			
    			if(!(ligne == i && colonne == j) && p != null)
    				if(p.getCouleur() == this.getCouleur())
    					pi�ces.add(p);
    		}
    	}
    	
    	for(Pi�ce p : pi�ces) {
    		ArrayList<Coordonn�e> aTester = p.coupsPossibles(e);
    		
    		for(Coordonn�e coord : aTester) {
    			Coordonn�e d�part = new Coordonn�e(p.getLigne(), p.getColonne());
    	    	Coordonn�e arriv�e = new Coordonn�e(coord.getLigne(), coord.getColonne());
    	    	
    	    	if (e.getPi�ce(arriv�e.getLigne(), arriv�e.getColonne()) != null)
    	    		priseV�rif = e.getPi�ce(arriv�e.getLigne(), arriv�e.getColonne());
    	    	e.d�placer(d�part, arriv�e);
    	    	
    	    	if(!this.�chec(e)) {
    	    		e.annulerDernierCoup(d�part, arriv�e);
    	    		e.setPi�ce(arriv�e.getLigne(), arriv�e.getColonne(), priseV�rif);
        			return true;
        		}
    	    	
    	    	e.annulerDernierCoup(d�part, arriv�e);
    	    	e.setPi�ce(arriv�e.getLigne(), arriv�e.getColonne(), priseV�rif);
    	    	priseV�rif = null;
    		}
    	}
    	return false;
    }
    
}