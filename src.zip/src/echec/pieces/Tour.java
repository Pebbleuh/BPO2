package echec.pieces;

import java.util.ArrayList;

import echec.Coordonn�e;
import echec.Echiquier;

public class Tour extends Pi�ce {

	/**
     * Constructeur d'une Tour
     * @param couleur
     * @param ligne
     * @param colonne
     */
    public Tour(String couleur, int ligne, int colonne) {
        super(couleur, ligne, colonne);
        this.type = "TOUR";
    }
    
    /**
     * V�rifie qu'un coup est possible pour la tour
     * @param e l'�chiquier actuel
     * @param x ligne
     * @param y colonne
     * @return true si le coup est possible
     */
    @Override
    public ArrayList<Coordonn�e> coupsPossibles(Echiquier e) {
    	ArrayList<Coordonn�e> coups = new ArrayList<Coordonn�e>();
    	
    	// bas
    	for (int i = ligne + 1; i < Echiquier.MAX; ++i) {
    		if(e.getPi�ce(i, colonne) != null
    				&& this.getCouleur() == e.getPi�ce(i, colonne).getCouleur())
    			break;
    		coups.add(new Coordonn�e(i, colonne));
    		if(e.getPi�ce(i, colonne) != null)
    			break;
    	}
    	
    	// haut
    	for (int i = ligne - 1; i >= Echiquier.MIN - 1; --i) {
    		if(e.getPi�ce(i, colonne) != null
    				&& this.getCouleur() == e.getPi�ce(i, colonne).getCouleur())
    			break;
    		coups.add(new Coordonn�e(i, colonne));
    		if(e.getPi�ce(i, colonne) != null)
    			break;
    	}
    	
    	// droite
    	for (int i = colonne + 1; i < Echiquier.MAX; ++i) {
    		if(e.getPi�ce(ligne, i) != null
    				&& this.getCouleur() == e.getPi�ce(ligne, i).getCouleur())
    			break;
    		coups.add(new Coordonn�e(ligne, i));
    		if(e.getPi�ce(ligne, i) != null)
    			break;
    	}
    	
    	//gauche
    	for (int i = colonne - 1; i >= Echiquier.MIN - 1; --i) {
    		if(e.getPi�ce(ligne, i) != null
    				&& this.getCouleur() == e.getPi�ce(ligne, i).getCouleur())
    			break;
    		coups.add(new Coordonn�e(ligne, i));
    		if(e.getPi�ce(ligne, i) != null)
    			break;
    	}
    	return coups;
    }
    
    /**
     * Retourne tous les coups possibles d'une tour sur l'�chiquier
     * @param e l'�chiquier actuel
     * @return coups la liste des coups possibles
     */
    @Override
    public boolean estPossible(Echiquier e, int x, int y) {
    	if(e.getPi�ce(x, y) != null
    			&& e.getPi�ce(x, y).getCouleur() == this.getCouleur())
    		return false;
    	if(!((colonne == y && ligne != x) || (colonne != y && ligne == x)))
    			return false;

    	if(colonne == y) {
    		// bas
    		if(ligne < x) {
    			for (int i = ligne + 1; i < x; ++i) {
    				if(e.getPi�ce(i, colonne) != null)
    					return false;
    			}
    		}
    	
    		// haut
    		if(ligne > x) {
    			for (int i = ligne - 1; i > x; --i) {
    				if(e.getPi�ce(i, colonne) != null)
    					return false;
    			}
    		}
    	}
    	
    	if(ligne == x) {
    		// droite
    		if(colonne < y) {
    			for (int i = colonne + 1; i < y; ++i) {
    				if(e.getPi�ce(ligne, i) != null)
    					return false;
    			}
    		}
    	
    		//gauche
    		if(colonne > y) {
    			for (int i = colonne - 1; i > y; --i) {
    				if(e.getPi�ce(ligne, i) != null)
    					return false;
    			}
    		}
    	}
    	
        return true;
    }

    /**
     * Retourne le caract�re repr�sentant la pi�ce
     * @return le caract�re
     */
    @Override
    public char getSymbole() {
    	return (couleur.equals("BLANC") ? 'T':'t');
    }

}