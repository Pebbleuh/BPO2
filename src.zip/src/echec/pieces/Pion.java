package echec.pieces;

import java.util.ArrayList;

import echec.Coordonn�e;
import echec.Echiquier;

public class Pion extends Pi�ce {
	private boolean premierCoup;
	
	/**
	 * Constructeur d'un Pion
	 * @param couleur
	 * @param ligne
	 * @param colonne
	 */
	public Pion(String couleur, int ligne, int colonne){
		super(couleur, ligne, colonne);
		this.premierCoup =  true;
		this.type = "PION";
	}
	
	/**
	 * V�rifie qu'un coup est possible pour le pion
	 * @param e l'�chiquier actuel
	 * @param x ligne
	 * @param y colonne
	 * @return true si le coup est possible
	 */
	@Override
    public boolean estPossible(Echiquier e, int x, int y) {
      	// pion blanc
    	if(this.couleur == "BLANC") {
    		// devant
    		if(ligne - 1 == x && colonne == y
    				&& e.getPi�ce(x, colonne) == null)
    			return true;
    		
    		// devant droite
    		if(ligne - 1 == x && colonne + 1 == y
    				&& e.getPi�ce(x, y) != null)
    			if(e.getPi�ce(x, y).getCouleur() != this.couleur)
    				return true;
    	
    		// devant gauche
    		if(ligne - 1 == x && colonne - 1 == y
    				&& e.getPi�ce(x, y) != null)
    			if(e.getPi�ce(x, y).getCouleur() != this.couleur)
    				return true;
    	
    		// 2 cases en avant
    		if(ligne - 2 == x && colonne == y
    				&& premierCoup
    				&& e.getPi�ce(x, colonne) == null
    				&& e.getPi�ce(ligne - 1, colonne) == null)
    			return true;
    	}
    	// pion noir
    	else {
    		// devant
    		if(ligne + 1 == x && colonne == y
    				&& e.getPi�ce(ligne + 1, colonne) == null)
    			return true;
    		
    		// devant droite
    		if(ligne + 1 == x && colonne + 1 == y
    				&& e.getPi�ce(x, y) != null)
    			if(e.getPi�ce(x, y).getCouleur() != this.couleur)
    				return true;
    	
    		// devant gauche
    		if(ligne + 1 == x && colonne - 1 == y
    				&& e.getPi�ce(x, y) != null)
    			if(e.getPi�ce(x, y).getCouleur() != this.couleur)
    				return true;
    	
    		// 2 cases en avant
    		if(ligne + 2 == x && colonne == y
    				&& premierCoup
    				&& e.getPi�ce(x, colonne) == null
    				&& e.getPi�ce(ligne + 1, colonne) == null)
    			return true;
    	}
        return false;
    }
    
    /**
	 * Retourne tous les coups possibles d'un pion sur l'�chiquier
	 * @param e l'�chiquier actuel
	 * @return coups la liste des coups possibles
	 */
	@Override
    public ArrayList<Coordonn�e> coupsPossibles(Echiquier e) {
    	ArrayList<Coordonn�e> coups = new ArrayList<Coordonn�e>();
    	
       	// pion blanc
    	if(this.couleur == "BLANC") {
    		// devant
    		if(ligne - 1 >= Echiquier.MIN - 1
    				&& e.getPi�ce(ligne - 1, colonne) == null)
    			coups.add(new Coordonn�e(ligne - 1, colonne));
    		
    		// devant droite
    		if(ligne - 1 >= Echiquier.MIN - 1 && colonne + 1 < Echiquier.MAX
    				&& e.getPi�ce(ligne - 1, colonne + 1) != null)
    			if(e.getPi�ce(ligne - 1, colonne + 1).getCouleur() != this.couleur)
    				coups.add(new Coordonn�e(ligne - 1, colonne + 1));
    	
    		// devant gauche
    		if(ligne - 1 >= Echiquier.MIN - 1 && colonne - 1 >= Echiquier.MIN - 1
    				&& e.getPi�ce(ligne - 1, colonne - 1) != null)
    			if(e.getPi�ce(ligne - 1, colonne - 1).getCouleur() != this.couleur)
    				coups.add(new Coordonn�e(ligne - 1, colonne - 1));
    	
    		// 2 cases en avant
    		if(ligne - 2 >= Echiquier.MIN - 1
    				&& premierCoup
    				&& e.getPi�ce(ligne - 2, colonne) == null
    				&& e.getPi�ce(ligne - 1, colonne) == null)
    			coups.add(new Coordonn�e(ligne - 2, colonne));
    	}
    	// pion noir
    	else {
    		// devant
    		if(ligne + 1 < Echiquier.MAX
    				&& e.getPi�ce(ligne + 1, colonne) == null)
    			coups.add(new Coordonn�e(ligne + 1, colonne));
    		
    		// devant droite
    		if(ligne + 1 < Echiquier.MAX && colonne + 1 < Echiquier.MAX
    				&& e.getPi�ce(ligne + 1, colonne + 1) != null)
    			if(e.getPi�ce(ligne + 1, colonne + 1).getCouleur() != this.couleur)
    				coups.add(new Coordonn�e(ligne + 1, colonne + 1));
    	
    		// devant gauche
    		if(ligne + 1 < Echiquier.MAX && colonne - 1 >= Echiquier.MIN - 1
    				&& e.getPi�ce(ligne + 1, colonne - 1) != null)
    			if(e.getPi�ce(ligne + 1, colonne - 1).getCouleur() != this.couleur)
    				coups.add(new Coordonn�e(ligne + 1, colonne - 1));
    	
    		// 2 cases en avant
    		if(ligne + 2 < Echiquier.MAX
    				&& premierCoup
    				&& e.getPi�ce(ligne + 2, colonne) == null
    				&& e.getPi�ce(ligne + 1, colonne) == null)
    			coups.add(new Coordonn�e(ligne + 2, colonne));
    	}
    	return coups;
    }
    
    /**
	 * Retourne le caract�re repr�sentant la pi�ce
	 * @return le caract�re
	 */
	@Override
    public char getSymbole() { 
		return (couleur.equals("BLANC") ? 'P':'p');
    }

    /**
	 * Modifie le bool�en du premier coup � false si le pion a d�j� boug� une fois
	 * @param b le bool�en donn�
	 */
	public void setPremierCoup(boolean b) {
		this.premierCoup = b;
	}
}
