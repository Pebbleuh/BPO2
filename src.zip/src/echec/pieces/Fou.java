package echec.pieces;

import java.util.ArrayList;

import echec.Coordonn�e;
import echec.Echiquier;

public class Fou extends Pi�ce {
	
	/**
	 * Constructeur d'un Fou
	 * @param couleur
	 * @param ligne
	 * @param colonne
	 */
	public Fou(String couleur, int ligne, int colonne) {
		super(couleur, ligne, colonne);
		this.type = "FOU";
	}
	
	/**
	 * Retourne tous les coups possibles d'un fou sur l'�chiquier
	 * @param e l'�chiquier actuel
	 * @return coups la liste des coups possibles
	 */
	@Override
	public ArrayList<Coordonn�e> coupsPossibles(Echiquier e) {
		ArrayList<Coordonn�e> coups = new ArrayList<Coordonn�e>();
		
		// sud-ouest
		for (int i = ligne - 1, j = colonne - 1;
				i >= Echiquier.MIN - 1 && j >= Echiquier.MIN - 1; --i, --j) {
	    	if(e.getPi�ce(i, j) != null
	    			&& this.couleur == e.getPi�ce(i, j).getCouleur())
	   			break;
	   		coups.add(new Coordonn�e(i, j));
	   		if(e.getPi�ce(i, j) != null)
	   			break;
	    }
		
		// sud-est
		for (int i = ligne - 1, j = colonne + 1;
				i >= Echiquier.MIN - 1 && j < Echiquier.MAX; --i, ++j) {
	    	if(e.getPi�ce(i, j) != null
	    			&& this.couleur == e.getPi�ce(i, j).getCouleur())
	    		break;
	    	coups.add(new Coordonn�e(i, j));
	    	if(e.getPi�ce(i, j) != null)
	   			break;
	    }
	    	
	    // nord-est
	   	for (int i = ligne + 1, j = colonne + 1;
	   			i < Echiquier.MAX && j < Echiquier.MAX; ++i, ++j) {
	   		if(e.getPi�ce(i, j) != null
	   				&& this.couleur == e.getPi�ce(i, j).getCouleur())
    			break;
    		coups.add(new Coordonn�e(i, j));
    		if(e.getPi�ce(i, j) != null)
    			break;
    	}
	    	
    	// nord-ouest
    	for (int i = ligne + 1, j = colonne - 1;
    			i < Echiquier.MAX && j >= Echiquier.MIN - 1; ++i, --j) {
    		if(e.getPi�ce(i, j) != null
    				&& this.couleur == e.getPi�ce(i, j).getCouleur())
    			break;
    		coups.add(new Coordonn�e(i, j));
    		if(e.getPi�ce(i, j) != null)
    			break;
    	}
    	return coups;
    }
	   
	/**
	 * V�rifie qu'un coup est possible pour le fou
	 * @param e l'�chiquier actuel
	 * @param x ligne
	 * @param y colonne
	 * @return true si le coup est possible
	 */
    @Override
    public boolean estPossible(Echiquier e, int x, int y) {
    	if(e.getPi�ce(x, y) != null
    			&& e.getPi�ce(x, y).getCouleur() == this.couleur)
    		return false;
    	
    	if(!(Math.abs(ligne - x) == Math.abs(colonne - y)))
    		return false; 
    	
    	// nord-ouest
    	if(ligne > x && colonne > y) {
    		for (int i = ligne - 1, j = colonne - 1; i > x && j > y; --i, --j) {
    			if(e.getPi�ce(i, j) != null)
    				return false;
    		}
    	}
    	
    	// nord-est
    	if(ligne > x && colonne < y) {
    		for (int i = ligne - 1, j = colonne + 1; i > x && j < y; --i, ++j) {
    			if(e.getPi�ce(i, j) != null)
    				return false;
    		}
    	}
    	
    	// sud-est
    	if(ligne < x && colonne < y) {
    		for (int i = ligne + 1, j = colonne + 1; i < x && j < y; ++i, ++j) {
    			if(e.getPi�ce(i, j) != null)
    				return false;
    		}
    	}
    	
    	// sud-ouest
    	if(ligne < x && colonne > y) {
    		for (int i = ligne + 1, j = colonne - 1; i < x && j > y; ++i, --j) {
    			if(e.getPi�ce(i, j) != null)
    				return false;
    		}
    	}
        return true;
    }
    
    /**
	 * Retourne le caract�re repr�sentant la pi�ce
	 * @return le caract�re
	 */
    @Override
    public char getSymbole() {
    	return (couleur.equals("BLANC") ? 'F':'f');
    }
}
