package echec;

import java.util.ArrayList;
import java.util.Random;

import echec.pieces.Pi�ce;

public class Joueur {
	private String type;
	private String couleur;
	
	/**
	 * Constructeur d'un Joueur
	 * @param type
	 * @param couleur
	 */
	public Joueur(String type, String couleur) {
		this.type = type;
		this.couleur = couleur;
	}
	
	/**
	 * Retourne le type de la pi�ce
	 * @return type
	 */
	public String getType() {
		return type;
	}
	
	/**
	 * Fait jouer l'IA
	 * @param p la partie actuelle
	 */
    public void jouerIA(Partie p) {  
    	String s = getCoupIA(p);
    	while(p.donneEchec(s)) {
    		s = getCoupIA(p);
    	}
    	Coordonn�e d�part = Coordonn�e.stringToInt(s)[0];
    	Coordonn�e arriv�e = Coordonn�e.stringToInt(s)[1];
    	p.getEchiquier().d�placer(d�part, arriv�e);
    }
    
    /**
	 * Choisit un coup al�atoire parmi la liste des coups possibles
	 * @param partie la partie en cours
	 * @return s le coup al�atoire de l'IA
	 */
    private String getCoupIA(Partie partie) {
       	ArrayList<Pi�ce> pi�ces = new ArrayList<>();
    	Pi�ce pi;
    	
    	if(this.couleur == "BLANC") {
    		pi�ces.addAll(partie.getEchiquier().getPi�cesBlanches());
    		Random r = new Random();
        	int nb = r.nextInt(pi�ces.size());
        	pi = pi�ces.get(nb);
        	
    		while(pi.coupsPossibles(partie.getEchiquier()).isEmpty()) {
    			nb = r.nextInt(pi�ces.size());
        		pi = pi�ces.get(nb);
    		}
    	}
    	else {
    		pi�ces.addAll(partie.getEchiquier().getPi�cesNoires());
    		Random r = new Random();
        	int nb = r.nextInt(pi�ces.size());
        	pi = pi�ces.get(nb);
        	
    		while(pi.coupsPossibles(partie.getEchiquier()).isEmpty()) {
    			nb = r.nextInt(pi�ces.size());
        		pi = pi�ces.get(nb);
    		}
    	}
    	
    	Coordonn�e d�part = new Coordonn�e(pi.getLigne(), pi.getColonne());
    	Random rand = new Random();
    	int i = rand.nextInt(pi.coupsPossibles(partie.getEchiquier()).size());
    	Coordonn�e arriv�e = pi.coupsPossibles(partie.getEchiquier()).get(i);
    	String s = Coordonn�e.intToString(d�part, arriv�e);
    	return s;
    }
    
}
