package echec;

import java.util.ArrayList;

import echec.pieces.Pi�ce;
import echec.pieces.Roi;

public class Echiquier {

    public static final int MIN = 1;
    public static final int MAX = 8;
    
    private Pi�ce[][] echiquier;
    private Roi roiBlanc;
    private Roi roiNoir;
    private Pi�ce priseDernierCoup;
    private Pi�ce priseDonneEchec;
    
    /**
     * Constructeur d'un Echiquier
     */
    public Echiquier() {
        this.echiquier = new Pi�ce[MAX][MAX];
        this.priseDernierCoup = null;
        this.setPriseDonneEchec(null);
        
        this.roiBlanc = new Roi("BLANC", 7,4);
        this.roiNoir = new Roi("NOIR", 0,4);
        
        for(int i = 0; i < MAX; i++){
			for(int j = 0; j < MAX; j++){
				echiquier[i][j] = null;
			}
		}
        Pi�ce.setEchiquier(this);
    }

    /**
     * Modifie la pi�ce aux coordonn�es x et y
     * @param x ligne
     * @param y colonne
     * @param p la nouvelle pi�ce
     */
	public void setPi�ce(int x, int y, Pi�ce p) {
        this.echiquier[x][y] = p;
    }
    
	/**
     * Retourne la pi�ce aux coordonn�es x et y
     * @param x ligne
     * @param y colonne
     * @return la pi�ce
     */
    public Pi�ce getPi�ce(int x, int y) {
    	return this.echiquier[x][y];
    }
    
    /**
     * Retourne le roi blanc
     * @return roiBlanc
     */
	public Roi getRoiBlanc() {
		return roiBlanc;
	}
	
	/**
     * Retourne le roi noire
     * @return roiNoir
     */
	public Roi getRoiNoir() {
		return roiNoir;
	}

	/**
     * Retourne la capture du coup entr�
     * qui met potentiellement le roi 
     * du joueur actif en echec
     * @return priseDonneEchec
     */
	public Pi�ce getPriseDonneEchec() {
		return priseDonneEchec;
	}

	/**
     * Met � jour la derni�re capture
     * lorsqu'on v�rifie si le coup entr�
     * met le roi du joueur actif en �chec
     * @param priseDonneEchec la nouvelle capture
     */
	public void setPriseDonneEchec(Pi�ce priseDonneEchec) {
		this.priseDonneEchec = priseDonneEchec;
	}
	
	/**
     * Retourne la derni�re capture
     * @return priseDernierCoup
     */
	public Pi�ce getPriseDernierCoup() {
		return priseDernierCoup;
	}
	
	/**
     * Met � jour la derni�re capture
     * @param p la nouvelle capture
     */
	public void setPriseDernierCoup(Pi�ce p) {
		this.priseDernierCoup = p;
	}
    
	/**
     * D�place la pi�ce d'une position de d�part � la position d'arriv�e
     * @param d�part
     * @param arriv�e
     */
    public void d�placer(Coordonn�e d�part, Coordonn�e arriv�e) {
    	int x = d�part.getLigne(), ligne = arriv�e.getLigne();
    	int y = d�part.getColonne(), colonne = arriv�e.getColonne();
    	
    	priseDernierCoup = null;
    	if(getPi�ce(ligne, colonne) != null)
    		priseDernierCoup = this.echiquier[ligne][colonne];
    	
    	this.echiquier[x][y].d�placer(this, d�part, arriv�e);
    }
    
    /**
     * Annule le dernier coup jou�
     * @param d�part les coordonn�es de d�part du dernier coup
     * @param arriv�e les coordonn�es d'arriv�e du dernier coup
     */
    public void annulerDernierCoup(Coordonn�e d�part, Coordonn�e arriv�e) {
    	int x = arriv�e.getLigne();
    	int y = arriv�e.getColonne();
    	
    	this.echiquier[x][y].d�placer(this, arriv�e, d�part);
    	if(priseDernierCoup != null)
    		setPi�ce(arriv�e.getLigne(), arriv�e.getColonne(), priseDernierCoup);
    	priseDernierCoup = null;
    }
    
    /**
     * Retourne toutes les pi�ces blanches du plateau
     * @return p la liste des pi�ces blanches
     */
    public ArrayList<Pi�ce> getPi�cesBlanches(){
    	ArrayList<Pi�ce> p = new ArrayList<>();
    	for(int i = 0; i < MAX; ++i) {
    		for(int j = 0; j < MAX; ++j) {
    			if(getPi�ce(i, j) != null
    					&& getPi�ce(i, j).getCouleur() == "BLANC")
    				p.add(getPi�ce(i, j));
    		}
    	}
    	return p;
    }
    
    /**
     * Retourne toutes les pi�ces noires du plateau
     * @return p la liste des pi�ces noires
     */
    public ArrayList<Pi�ce> getPi�cesNoires(){
    	ArrayList<Pi�ce> p = new ArrayList<>();
    	for(int i = 0; i < MAX; ++i) {
    		for(int j = 0; j < MAX; ++j) {
    			if(getPi�ce(i, j) != null
    					&& getPi�ce(i, j).getCouleur() == "NOIR")
    				p.add(getPi�ce(i, j));
    		}
    	}
    	return p;
    }
    
    /**
     * Affiche le plateau et les pi�ces sous forme de grille
     * @return s la grille
     */
    public String toString() {
        String lettres = ("    a   b   c   d   e   f   g   h    \n");
        String trait = "   --- --- --- --- --- --- --- ---   \n";
        String s = lettres + trait;
        // ligne
        for (int i = MIN; i <= MAX; ++i) {
            s += MAX - i + 1 + " | ";
            // colonne
            for (int j = MIN; j <= MAX; ++j) {
            	if(this.echiquier[i-1][j-1] != null)
            		s += this.echiquier[i-1][j-1].getSymbole();
                else
                    s += " ";
            	s += " | ";
            }
            s += (MAX-i+1) + "\n";
            s += trait;
        }
        s += lettres;
        return s;
    }

}
