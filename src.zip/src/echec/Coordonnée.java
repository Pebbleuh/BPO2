package echec;

import java.util.ArrayList;

public class Coordonn�e {
	private int ligne;
	private int colonne;
	
	/**
     * Constructeur d'une Coordonn�e
     * @param x ligne
     * @param y colonne
     */
	public Coordonn�e(int x, int y) {
		this.ligne = x;
		this.colonne = y;
	}
	
	/**
     * Retourne la coordonn�e (un entier) d'une ligne
     * @return ligne
     */
	public int getLigne() {
		return ligne;
	}
	
	/**
     * Retourne la coordonn�e (un entier) d'une colonne
     * @return colonne
     */
	public int getColonne() {
		return colonne;
	}	
	
	/**
    * Affiche les coordonn�es ligne et colonne
    * @return L'affichage des coordonn�es
    */
	public String toString(){
		return "[" + ligne + ", " + colonne + "]";
	}
	
	/**
     * Convertit le coup du joueur en coordonn�es (entiers)
     * @param s le coup
     * @return c les coordonn�es
     */
	public static Coordonn�e[] stringToInt(String s) {
		ArrayList<Character> tmp = new ArrayList<>();
		tmp.add('8'); tmp.add('7'); tmp.add('6'); tmp.add('5');
		tmp.add('4'); tmp.add('3'); tmp.add('2'); tmp.add('1');
		
		s = s.replaceAll("\\s+","");
        s = s.toLowerCase();
		Coordonn�e d�part =
				new Coordonn�e(tmp.indexOf(s.charAt(1)),
						(int) s.charAt(0) - 97);
		Coordonn�e arriv�e =
				new Coordonn�e(tmp.indexOf(s.charAt(3)),
						(int) s.charAt(2) - 97);
		Coordonn�e[] c = { d�part, arriv�e };
		return c;
	}
	
	/**
     * Convertit les coordonn�es en coup (String)
     * @param d�part
     * @param arriv�e
     * @return s le coup
     */
	public static String intToString(Coordonn�e d�part, Coordonn�e arriv�e) {
		ArrayList<String> lettre = new ArrayList<>();
		lettre.add("a"); lettre.add("b"); lettre.add("c"); lettre.add("d");
		lettre.add("e"); lettre.add("f"); lettre.add("g"); lettre.add("h");
		
		ArrayList<String> chiffre = new ArrayList<>();
		chiffre.add("8"); chiffre.add("7"); chiffre.add("6"); chiffre.add("5");
		chiffre.add("4"); chiffre.add("3"); chiffre.add("2"); chiffre.add("1");
		
		String s = lettre.get(d�part.getColonne()) + chiffre.get(d�part.getLigne());
		s += lettre.get(arriv�e.getColonne()) + chiffre.get(arriv�e.getLigne());
		return s;
	}
	
}
