package echec;

import java.util.ArrayList;

import echec.pieces.Pi�ce;
import echec.pieces.Roi;

public class Partie {
	private Joueur blanc;
	private Joueur noir;
	private Echiquier echiquier;
	private boolean tourDeBlanc;
	private int nbCoupsSansPrises;
	
	/**
	 * Constructeur d'une Partie
	 * @param typeBlanc Humain ou IA pour le joueur blanc
	 * @param typeNoir Humain ou IA pour le joueur noir
	 */
	public Partie(String typeBlanc, String typeNoir) {
		if(typeBlanc.equals("Humain"))
			blanc = new Joueur("Humain", "BLANC");
		else
			blanc = new Joueur("IA", "BLANC");
		
		if(typeNoir.equals("Humain"))
			noir = new Joueur("Humain", "NOIR");
		else
			noir = new Joueur("IA", "NOIR");
		
		this.echiquier = new Echiquier();
		this.tourDeBlanc = true;
		this.nbCoupsSansPrises = 0;
	}

	/**
	 * V�rifie si c'est au tour du joueur blanc
	 * @return tourDeBlanc
	 */
	public boolean isTourDeBlanc() {
		return tourDeBlanc;
	}

	/**
	 * Passe d'un tour � l'autre
	 * @param b le bool�en pour changer le tour
	 */
	public void setTourDeBlanc(boolean b) {
		this.tourDeBlanc = b;
	}
	
	/**
	 * Retourne l'�chiquier
	 * @return �chiquier
	 */
	public Echiquier getEchiquier() {
		return echiquier;
	}
	
	/**
	 * Le joueur saisit son coup et d�place la pi�ce
	 * @param s le coup saisi
	 */
	public void jouer(String s) {
		if(tourDeBlanc) {
			if(blanc.getType() == "Humain") {
				Coordonn�e d�part = Coordonn�e.stringToInt(s)[0];
				Coordonn�e arriv�e = Coordonn�e.stringToInt(s)[1];
				echiquier.d�placer(d�part, arriv�e);
			}
			else
				blanc.jouerIA(this);
		}
		else {
			if(noir.getType() == "Humain") {
				Coordonn�e d�part = Coordonn�e.stringToInt(s)[0];
				Coordonn�e arriv�e = Coordonn�e.stringToInt(s)[1];
				echiquier.d�placer(d�part, arriv�e);
			}
			else
				noir.jouerIA(this);
		}
		if(echiquier.getPriseDernierCoup() == null)
			nbCoupsSansPrises += 1;
		else
			nbCoupsSansPrises = 0;
		if(isTourDeBlanc())
			tourDeBlanc = false;
		else
			tourDeBlanc = true;
	}
	
	/**
	 * V�rifie si le coup saisi est possible
	 * @param s le coup saisi
	 * @return true si le coup saisi est possible
	 */
    public boolean estPossible(String s) {
    	Coordonn�e d�part = Coordonn�e.stringToInt(s)[0];
    	Coordonn�e arriv�e = Coordonn�e.stringToInt(s)[1];
    	Pi�ce p = echiquier.getPi�ce(d�part.getLigne(), d�part.getColonne());
    	if(p == null)
    		return false;
    	if(!p.estPossible(echiquier, arriv�e.getLigne(), arriv�e.getColonne())
    			|| (p.getCouleur().equals("NOIR") && tourDeBlanc)
    			|| (p.getCouleur().equals("BLANC") && !tourDeBlanc))
    		return false;
    	return true;
    }
    
    /**
	 * V�rifie si le coup jou� met en �chec le roi du joueur actif
	 * @param s le coup saisi
	 * @return b true si le coup met en �chec le roi
	 */
    public boolean donneEchec(String s) {
    	Coordonn�e d�part = Coordonn�e.stringToInt(s)[0];
    	Coordonn�e arriv�e = Coordonn�e.stringToInt(s)[1];
    	boolean b = false;
    	
    	if(echiquier.getPi�ce(arriv�e.getLigne(), arriv�e.getColonne()) != null)
    		echiquier.setPriseDonneEchec(echiquier.getPi�ce(arriv�e.getLigne(), arriv�e.getColonne()));
    	echiquier.d�placer(d�part, arriv�e);
    	
    	if(tourDeBlanc
    			&& echiquier.getRoiBlanc().�chec(echiquier))
    		b = true;
    	
    	if(!tourDeBlanc
    			&& echiquier.getRoiNoir().�chec(echiquier))
    		b = true;
    	
    	echiquier.annulerDernierCoup(d�part, arriv�e);
    	if(echiquier.getPriseDonneEchec() != null)
    		echiquier.setPi�ce(arriv�e.getLigne(), arriv�e.getColonne(), echiquier.getPriseDonneEchec());
    	echiquier.setPriseDonneEchec(null);
    	return b;
    }
    
    /**
	 * V�rifie si le joueur n'a plus aucun coup � jouer
	 * @return true s'il n'a plus aucun coup possible
	 */
    private boolean pat() {
    	for(int i = 0; i < Echiquier.MAX; ++i) {
    		for(int j = 0; j < Echiquier.MAX; ++j) {
    			Pi�ce p = echiquier.getPi�ce(i, j);
    			if(p != null) {
    				if(tourDeBlanc) {
    					if(p.getCouleur() == "BLANC"
    							&& !p.coupsPossibles(echiquier).isEmpty())
    						return false;
    				}
    				else {
    					if(p.getCouleur() == "NOIR"
							&& !p.coupsPossibles(echiquier).isEmpty())
    					return false;
    				}
    			}
    		}
    	}
    	return true;
    }
    
    /**
	 * V�rifie s'il y a eu 50 coups sans prise ou non
	 * @return true s'il y a eu 50 coups sans prise
	 */
    private boolean cinquanteCoups() {
    	return (nbCoupsSansPrises == 50);
    }
    
    /**
	 * V�rifie s'il y a insuffisance de mat�riel ou non
	 * @return true s'il y a insuffisance de mat�riel
	 */
    private boolean mat�rielInsuffisant() {
    	ArrayList<Pi�ce> blancs = echiquier.getPi�cesBlanches();
    	ArrayList<Pi�ce> noirs = echiquier.getPi�cesNoires();
    	
    	if(blancs.size() == 1 && noirs.size() == 1)
    		return true;
    	
    	if(blancs.size() == 1 && noirs.size() == 2)
    		if(noirs.get(0).getType() == "CAVALIER" || noirs.get(1).getType() == "CAVALIER"
    				|| noirs.get(0).getType() == "FOU" || noirs.get(1).getType() == "FOU")
    			return true;
    	
    	if(blancs.size() == 2 && noirs.size() == 1)
    		if(blancs.get(0).getType() == "CAVALIER" || blancs.get(1).getType() == "CAVALIER"
    				|| blancs.get(0).getType() == "FOU" || blancs.get(1).getType() == "FOU")
    			return true;
    	
    	if(blancs.size() == 2 && noirs.size() == 2)
    		if((blancs.get(0).getType() == "FOU" || blancs.get(1).getType() == "FOU")
    				&& (noirs.get(0).getType() == "FOU" || noirs.get(1).getType() == "FOU"))
    			return true;
    	
    	return false;
    }
    

	/**
	 * V�rifie s'il y a �chec et mat pour un roi
	 * @param roi le roi � v�rifier
	 * @return false s'il n'y a pas �chec et mat
	 */
    private boolean �checEtMat(Roi roi) {    	
    	Coordonn�e initial = new Coordonn�e(roi.getLigne(), roi.getColonne());
    	if(roi.�chec(echiquier)) {
    		for(Coordonn�e coups : roi.coupsPossibles(echiquier)) {
    			echiquier.d�placer(initial, coups);
    			if(!roi.�chec(echiquier)) {
    				echiquier.annulerDernierCoup(initial, coups);
    				return false;
    			}
    			echiquier.annulerDernierCoup(initial, coups);
    		}
    		if(roi.peutEtreProt�g�(echiquier))
    			return false;
    		
    		return true;
    	}
    	return false;
    }
    
    /**
	 * V�rifie si la partie est finie ou non
	 * @return true si elle est finie
	 */
    public boolean fin() {
    	if(this.pat() || cinquanteCoups() || mat�rielInsuffisant()
    			|| (�checEtMat(echiquier.getRoiBlanc()) && tourDeBlanc)
    			|| (�checEtMat(echiquier.getRoiNoir()) && !tourDeBlanc))
    		return true;
    	return false;
    }
    
    /**
	 * V�rifie si un joueur abandonne la partie
	 * @param s le coups saisi
	 * @return true si le coup saisie est vide
	 */
    public boolean abandon(String s) {
		return (s.length() == 0);
	}

    /**
	 * Affiche le r�sultat de fin de partie selon la situation
	 * @param s le dernier coup saisi
	 * @return fin le r�sultat
	 */
	public String toStringFin(String s) {
		String fin = "";
		
		if(s.length() == 0) {
			fin += "partie finie, abandon des ";
			if(tourDeBlanc)
				fin += "Blancs";
			else
				fin += "Noirs";
		}
		
		else if(cinquanteCoups())
			fin += "partie nulle, r�gle des Cinquantes Coups";
		
		else if(mat�rielInsuffisant())
			fin += "partie nulle, mat�riel insuffisant";
		
		else if(pat())
			fin += "partie nulle, PAT";
		
		else if(�checEtMat(echiquier.getRoiBlanc()))
			fin += "les Noirs ont gagn� par Echec Et Mat";
		
		else if(�checEtMat(echiquier.getRoiNoir()))
			fin += "les Blancs ont gagn� par Echec Et Mat";
    	
    	return fin;
    }
	
}
