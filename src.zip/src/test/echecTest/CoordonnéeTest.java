package test.echecTest;

import static org.junit.Assert.assertEquals;
import org.junit.Test;
import echec.Coordonn�e;

public class Coordonn�eTest {
	
	@Test
	public void testToString() {
		Coordonn�e c = new Coordonn�e(0, 4);
		String attendu = "[0, 4]";
		assertEquals(c.toString(), attendu);
	}
	
	@Test
	public void testStringToInt() {
		Coordonn�e[] c = Coordonn�e.stringToInt("a8h1");
		Coordonn�e[] coord = Coordonn�e.stringToInt("b3d4");
		assertEquals(c[0].toString(), "[0, 0]");
		assertEquals(c[1].toString(), "[7, 7]");
		assertEquals(coord[0].toString(), "[5, 1]");
		assertEquals(coord[1].toString(), "[4, 3]");
	}
	
	@Test
	public void testIntToString() {
		Coordonn�e arriv�e = new Coordonn�e(0,0);
		Coordonn�e d�part = new Coordonn�e(7,7);
		String c = Coordonn�e.intToString(arriv�e, d�part);
		assertEquals(c, "a8h1");
		
		d�part = new Coordonn�e(5, 1);
		arriv�e = new Coordonn�e(4, 3);
		String coord = Coordonn�e.intToString(d�part, arriv�e);
		assertEquals(coord, "b3d4");
	}
}
