package test.echecTest;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import echec.Coordonn�e;
import echec.Echiquier;

public class EchiquierTest {
	
	@Test
	public void testD�placer() {
		Echiquier e = new Echiquier();
		assert(e.getPi�ce(4,7) == null);
		assert(e.getPi�ce(6,7).getSymbole() == 'P');
		e.d�placer(new Coordonn�e(6, 7), new Coordonn�e(4, 7));
		assert(e.getPi�ce(4,7) != null && e.getPi�ce(4,7).getSymbole() == 'P');
		assert(e.getPi�ce(6,7) == null);
		
		assert(e.getPi�ce(1,7) != null && e.getPi�ce(1,7).getSymbole() == 'p');
		e.d�placer(new Coordonn�e(4, 7), new Coordonn�e(1, 7));
		assert(e.getPi�ce(1,7) != null && e.getPi�ce(1, 7).getSymbole() == 'P');
		assert(e.getPi�ce(4,7) == null);
	}
	
	@Test
	public void testAnnulerDernierCoup() {
		Echiquier e = new Echiquier();
		
		assert(e.getPi�ce(4,7) == null);
		assert(e.getPi�ce(6,7).getSymbole() == 'P');
		e.d�placer(new Coordonn�e(6, 7), new Coordonn�e(4, 7));
		e.annulerDernierCoup(new Coordonn�e(6, 7), new Coordonn�e(4, 7));
		assert(e.getPi�ce(4,7) == null);
		assert(e.getPi�ce(6,7).getSymbole() == 'P');
		
		assert(e.getPi�ce(1,7) != null && e.getPi�ce(1,7).getSymbole() == 'p');
		e.d�placer(new Coordonn�e(6, 7), new Coordonn�e(1, 7));
		e.annulerDernierCoup(new Coordonn�e(6, 7), new Coordonn�e(1, 7));
		assert(e.getPi�ce(1,7) != null && e.getPi�ce(1,7).getSymbole() == 'p');
		assert(e.getPi�ce(6,7).getSymbole() == 'P');
	}
	
	@Test
	public void testGetPi�cesBlanches() {
		Echiquier e = new Echiquier();
		String attendu = "[BLANC[6, 0], BLANC[6, 1], BLANC[6, 2], "
				+ "BLANC[6, 3], BLANC[6, 4], BLANC[6, 5], "
				+ "BLANC[6, 6], BLANC[6, 7], BLANC[7, 0], "
				+ "BLANC[7, 1], BLANC[7, 2], BLANC[7, 3], "
				+ "BLANC[7, 4], BLANC[7, 5], BLANC[7, 6], BLANC[7, 7]]";
		assertEquals(attendu, e.getPi�cesBlanches().toString());
	}
	
	@Test
	public void testGetPi�cesNoires() {
		Echiquier e = new Echiquier();
		String attendu = "[NOIR[0, 0], NOIR[0, 1], NOIR[0, 2], "
				+ "NOIR[0, 3], NOIR[0, 4], NOIR[0, 5], "
				+ "NOIR[0, 6], NOIR[0, 7], NOIR[1, 0], "
				+ "NOIR[1, 1], NOIR[1, 2], NOIR[1, 3], "
				+ "NOIR[1, 4], NOIR[1, 5], NOIR[1, 6], NOIR[1, 7]]";
		assertEquals(attendu, e.getPi�cesNoires().toString());
	}
	
	@Test
	public void testToString() {
		Echiquier e = new Echiquier();
		String attendu = "    a   b   c   d   e   f   g   h    \n"
				+ "   --- --- --- --- --- --- --- ---   \n"
				+ "8 | t | c | f | d | r | f | c | t | 8\n"
				+ "   --- --- --- --- --- --- --- ---   \n"
				+ "7 | p | p | p | p | p | p | p | p | 7\n"
				+ "   --- --- --- --- --- --- --- ---   \n"
				+ "6 |   |   |   |   |   |   |   |   | 6\n"
				+ "   --- --- --- --- --- --- --- ---   \n"
				+ "5 |   |   |   |   |   |   |   |   | 5\n"
				+ "   --- --- --- --- --- --- --- ---   \n"
				+ "4 |   |   |   |   |   |   |   |   | 4\n"
				+ "   --- --- --- --- --- --- --- ---   \n"
				+ "3 |   |   |   |   |   |   |   |   | 3\n"
				+ "   --- --- --- --- --- --- --- ---   \n"
				+ "2 | P | P | P | P | P | P | P | P | 2\n"
				+ "   --- --- --- --- --- --- --- ---   \n"
				+ "1 | T | C | F | D | R | F | C | T | 1\n"
				+ "   --- --- --- --- --- --- --- ---   \n"
				+ "    a   b   c   d   e   f   g   h    \n";
		assertEquals(e.toString(), attendu);
	}

}
