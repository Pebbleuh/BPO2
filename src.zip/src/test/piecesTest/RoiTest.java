package test.piecesTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import echec.Coordonn�e;
import echec.Echiquier;
import echec.pieces.Roi;

public class RoiTest {
	@Test
	public void testEstPossible() {
		Echiquier e = new Echiquier();
		Roi r = new Roi("BLANC", 4, 4);
		
		assertTrue(r.estPossible(e, 3, 3));
		assertTrue(r.estPossible(e, 3, 4));
		assertTrue(r.estPossible(e, 3, 5));
		assertTrue(r.estPossible(e, 4, 3));
		assertTrue(r.estPossible(e, 4, 5));
		assertTrue(r.estPossible(e, 5, 3));
		assertTrue(r.estPossible(e, 5, 4));
		assertTrue(r.estPossible(e, 5, 4));
		
		assertFalse(r.estPossible(e, 5, 6));
		assertFalse(r.estPossible(e, 6, 5));
		assertFalse(r.estPossible(e, 2, 2));
	}
	
	@Test
	public void testCoupsPossibles() {
		Echiquier e = new Echiquier();
		Roi r = new Roi("BLANC", 4, 4);
		e.setPi�ce(4, 4, r);
		
		String attendu = "[[3, 3], [3, 4], [3, 5], [4, 3], "
				+ "[4, 5], [5, 3], [5, 4], [5, 5]]";
		assertEquals(r.coupsPossibles(e).toString(), attendu);
	}
	
	@Test
	public void testGetSymbole() {
		Roi r = new Roi("BLANC", 0, 0);
		assertEquals(r.getSymbole(), 'R');
		
		r = new Roi("NOIR", 0, 0);
		assertEquals(r.getSymbole(), 'r');
	}
	
	@Test
	public void testEchec() {
		Echiquier e = new Echiquier();
		assertFalse(e.getRoiBlanc().�chec(e));
		
		Coordonn�e d�part = new Coordonn�e(0, 4);
		Coordonn�e arriv�e = new Coordonn�e(5, 4);
		e.d�placer(d�part, arriv�e);
		assertTrue(e.getRoiNoir().�chec(e));
		
		d�part = new Coordonn�e(5, 4);
		arriv�e = new Coordonn�e(4, 4);
		e.d�placer(d�part, arriv�e);
		assertFalse(e.getRoiNoir().�chec(e));
		
		d�part = new Coordonn�e(7, 7);
		arriv�e = new Coordonn�e(4, 7);
		e.d�placer(d�part, arriv�e);
		assertTrue(e.getRoiNoir().�chec(e));
	}
	
	@Test
	public void testPeutEtreProt�g�() {
		Echiquier e = new Echiquier();
		assertFalse(e.getRoiBlanc().�chec(e));
		
		Coordonn�e d�part = new Coordonn�e(0, 4);
		Coordonn�e arriv�e = new Coordonn�e(5, 4);
		e.d�placer(d�part, arriv�e);
		assertFalse(e.getRoiNoir().peutEtreProt�g�(e));
		
		d�part = new Coordonn�e(5, 4);
		arriv�e = new Coordonn�e(4, 4);
		e.d�placer(d�part, arriv�e);
		
		d�part = new Coordonn�e(7, 7);
		arriv�e = new Coordonn�e(4, 7);
		e.d�placer(d�part, arriv�e);
		
		d�part = new Coordonn�e(0, 3);
		arriv�e = new Coordonn�e(5, 4);
		e.d�placer(d�part, arriv�e);
		assertTrue(e.getRoiNoir().peutEtreProt�g�(e));
		
		d�part = new Coordonn�e(5, 4);
		arriv�e = new Coordonn�e(5, 7);
		e.d�placer(d�part, arriv�e);
		assertTrue(e.getRoiNoir().peutEtreProt�g�(e));
	}
}
