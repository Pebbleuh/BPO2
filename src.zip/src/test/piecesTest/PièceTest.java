package test.piecesTest;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import echec.Coordonn�e;
import echec.Echiquier;
import echec.pieces.Pi�ce;

public class Pi�ceTest {
	
	@Test
	public void testD�placer() {
		Echiquier e = new Echiquier();
		Pi�ce p = new Pi�ce("BLANC", 4, 4);
		e.setPi�ce(4, 4, p);
		Coordonn�e d�part = new Coordonn�e(4, 4);
		Coordonn�e arriv�e = new Coordonn�e(0, 0);
		
		p.d�placer(e, d�part, arriv�e);
		assertTrue(e.getPi�ce(4, 4) == null);
		assertTrue(e.getPi�ce(0, 0) == p);
	}
	
}
